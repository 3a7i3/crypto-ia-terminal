// WEB-01G local frontend runtime. This server deliberately exposes one local
// read-only presentation surface only: static frontend assets plus GET/HEAD
// proxying to the loopback Operator API. It never reads runtime artifacts.
import { createReadStream, realpathSync } from "node:fs";
import { stat } from "node:fs/promises";
import http from "node:http";
import https from "node:https";
import path from "node:path";
import { startPaperBalanceHistory } from "./paper-balance-history.mjs";
import { fileURLToPath } from "node:url";

export const LOOPBACK_HOST = "127.0.0.1";
export const FRONTEND_PORT = 8181;
export const FRONTEND_PORT_ENV = "CAT_WEB_PORT";
export const OPERATOR_API_TARGET = "http://127.0.0.1:8090";
// Radar Spot read API (loopback only). Only this exact path prefix is routed
// there; every other API path keeps the Operator API target.
export const SPOT_RADAR_API_PREFIX = "/api/operator/v1/spot-radar/";
export const SPOT_RADAR_API_TARGET = "http://127.0.0.1:18906";
export const UPSTREAM_TIMEOUT_MS = 10000;

// The contractual port is FRONTEND_PORT. An explicit CAT_WEB_PORT may select
// another unprivileged port; anything else (empty, signed, decimal, leading
// zero, out of 1024-65535) is refused rather than silently replaced.
export function resolveFrontendPort(raw = process.env[FRONTEND_PORT_ENV]) {
  if (raw === undefined) return FRONTEND_PORT;
  if (typeof raw !== "string" || !/^[1-9][0-9]{3,4}$/.test(raw)) throw new Error("INVALID_CAT_WEB_PORT");
  const port = Number(raw);
  if (port < 1024 || port > 65535) throw new Error("INVALID_CAT_WEB_PORT");
  return port;
}

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const DEFAULT_DIST_ROOT = path.join(ROOT, "dist");
const HOP_BY_HOP_HEADERS = new Set(["connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailer", "transfer-encoding", "upgrade"]);
const MIME_TYPES = new Map([
  [".css", "text/css; charset=utf-8"],
  [".html", "text/html; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".map", "application/json; charset=utf-8"],
  [".png", "image/png"],
  [".svg", "image/svg+xml"],
  [".webmanifest", "application/manifest+json; charset=utf-8"],
  [".woff2", "font/woff2"],
]);

export function isMainEntrypoint(entryPath = process.argv[1], moduleUrl = import.meta.url) {
  if (!entryPath) return false;
  try {
    return realpathSync(entryPath) === realpathSync(fileURLToPath(moduleUrl));
  } catch {
    return false;
  }
}

function apiError(response, status, code, message) {
  response.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
  response.end(JSON.stringify({ error_code: code, error_message: message }));
}

function methodAllowed(request) {
  return request.method === "GET" || request.method === "HEAD";
}

function isApiPath(pathname) {
  return pathname === "/api" || pathname.startsWith("/api/") || pathname === "/healthz";
}

function copyProxyHeaders(headers) {
  const safe = {};
  for (const [name, value] of Object.entries(headers)) {
    if (value !== undefined && !HOP_BY_HOP_HEADERS.has(name.toLowerCase())) safe[name] = value;
  }
  return safe;
}

function proxyToOperatorApi(request, response, target) {
  const transport = target.protocol === "https:" ? https : http;
  const upstream = transport.request({
    protocol: target.protocol,
    hostname: target.hostname,
    port: target.port,
    method: request.method,
    path: request.url,
    headers: { host: target.host },
  }, (upstreamResponse) => {
    const headers = copyProxyHeaders(upstreamResponse.headers);
    // WEB-01B runtime truth must remain network-only from the browser/PWA
    // perspective even when an upstream route omits explicit cache metadata.
    // Override any upstream cache directive at the presentation boundary.
    headers["cache-control"] = "no-store";
    response.writeHead(upstreamResponse.statusCode ?? 502, headers);
    if (request.method === "HEAD") response.end();
    else {
      upstreamResponse.once("error", () => response.destroy());
      upstreamResponse.once("aborted", () => response.destroy());
      upstreamResponse.pipe(response);
    }
  });
  upstream.setTimeout(UPSTREAM_TIMEOUT_MS, () => upstream.destroy(new Error("UPSTREAM_TIMEOUT")));
  upstream.once("error", () => failRequest(response, 502, "OPERATOR_API_UNAVAILABLE", "Local Operator API is unavailable."));
  request.pipe(upstream);
}

async function resolveStaticPath(distRoot, pathname) {
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { return null; }
  const candidate = path.resolve(distRoot, `.${decoded}`);
  if (candidate !== distRoot && !candidate.startsWith(`${distRoot}${path.sep}`)) return null;
  try {
    return (await stat(candidate)).isFile() ? candidate : null;
  } catch {
    return null;
  }
}

async function serveFile(response, filename, method) {
  const info = await stat(filename);
  const basename = path.basename(filename);
  const ext = path.extname(filename);
  const headers = {
    "content-type": MIME_TYPES.get(ext) ?? "application/octet-stream",
    "content-length": info.size,
    "x-content-type-options": "nosniff",
    "cache-control": "no-store",
  };
  if (basename === "sw.js" || basename === "pwa-policy.js" || ext === ".webmanifest") {
    headers["cache-control"] = "no-cache";
  }
  response.writeHead(200, headers);
  if (method === "HEAD") return response.end();
  const stream = createReadStream(filename);
  stream.once("error", () => response.destroy());
  stream.pipe(response);
}

// Every request failure becomes a structured answer or a closed connection;
// a handler rejection must never terminate the process (systemd restart loop).
function failRequest(response, status, code, message) {
  if (response.destroyed) return;
  if (response.headersSent) response.destroy();
  else apiError(response, status, code, message);
}

export function createServer({ host = LOOPBACK_HOST, port = FRONTEND_PORT, distRoot = DEFAULT_DIST_ROOT, apiTarget = OPERATOR_API_TARGET, spotRadarTarget = SPOT_RADAR_API_TARGET, balanceHistory } = {}) {
  const target = new URL(apiTarget);
  const spotRadar = new URL(spotRadarTarget);
  return http.createServer(async (request, response) => {
    try {
      let url;
      try { url = new URL(request.url ?? "/", `http://${host}`); } catch {
        return failRequest(response, 400, "INVALID_REQUEST_URL", "Request target is not a valid URL.");
      }
      if (!methodAllowed(request)) return apiError(response, 405, "METHOD_NOT_ALLOWED", "WEB-01G accepts GET and HEAD only.");
      if (balanceHistory && url.pathname === "/api/operator/v1/paper-balance-history") {
        const period = url.searchParams.get("days") ?? "1";
        if (!["1", "7", "30"].includes(period)) return apiError(response, 400, "INVALID_PERIOD", "Expected 1, 7 or 30 days.");
        response.writeHead(200, { "content-type": "application/json", "cache-control": "no-store" });
        response.end(request.method === "HEAD" ? undefined : JSON.stringify(balanceHistory(Number(period))));
        return;
      }
      if (isApiPath(url.pathname)) {
        const selected = url.pathname.startsWith(SPOT_RADAR_API_PREFIX) ? spotRadar : target;
        return proxyToOperatorApi(request, response, selected);
      }

      const requested = await resolveStaticPath(distRoot, url.pathname);
      // SPA fallback applies only to non-API frontend routes; API paths never
      // reach this branch, including when the Operator API is unavailable.
      await serveFile(response, requested ?? path.join(distRoot, "index.html"), request.method);
    } catch {
      failRequest(response, 503, "FRONTEND_ASSET_UNAVAILABLE", "Frontend bundle is unavailable.");
    }
  }).listen(port, host);
}

if (isMainEntrypoint()) {
  let port;
  try { port = resolveFrontendPort(); } catch (error) {
    console.error(`WEB_01G_CONFIG_REFUSED=${error.message}`);
    process.exit(2);
  }
  const stateDirectory = process.env.STATE_DIRECTORY;
  const balanceHistory = stateDirectory ? startPaperBalanceHistory(stateDirectory, OPERATOR_API_TARGET) : undefined;
  createServer({ port, balanceHistory }).on("listening", () => console.log(`WEB_01G_LOCAL_FRONTEND_LISTENING=${LOOPBACK_HOST}:${port}`));
}
